import React from 'react';
import './App.css';
import MainMenuScene from './Components/MainMenuScene';

function App() {
  return (
    <div className="App">
      <div className="App-main">
        <MainMenuScene />
      </div>
    </div>
  );
}

export default App;
