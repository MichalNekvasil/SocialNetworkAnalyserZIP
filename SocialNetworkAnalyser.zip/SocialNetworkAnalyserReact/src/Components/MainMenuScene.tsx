import React, { useEffect, useState } from 'react';
import { Pageview, Publish } from '@mui/icons-material';
import { Button } from '@mui/material';
import ImportDatasetScene from './ImportDatasetScene';
import DatasetStatisticScene from './DatasetStatisticScene';

interface MainMenuSceneProps {
}

function MainMenuScene(props: MainMenuSceneProps) {

    const [importOpen, setImportOpen] = useState(false);
    const [statsOpen, setStatsOpen] = useState(false);

    useEffect(() => {
    }, []);

    const handleImportClick = () => {
        setImportOpen(true);
    };

    const handleSearchDatasetClick = () => {
        setStatsOpen(true);
    };

    function importClosed() { setImportOpen(false); }
    function statsClosed() { setStatsOpen(false); }

    return (
        <div>
            <div style={{ display: "flex", flexDirection: 'column', justifyContent: 'start', margin: 'auto' }}>
            <Button 
                sx={{ borderRadius: 10, margin: 2 }}
                variant="contained"
                onClick={handleImportClick}
                startIcon={<Publish/>}
            >
                Importovat dataset
            </Button>
            <Button 
                sx={{ borderRadius: 10, margin: 2 }}
                variant="contained"
                onClick={handleSearchDatasetClick}
                startIcon={<Pageview/>}
            >
                Prohlížet datasety
            </Button>
            </div>
            <ImportDatasetScene open={importOpen} onClose={importClosed}/>
            <DatasetStatisticScene open={statsOpen} onClose={statsClosed}/>
        </div>
    );    
};
export default MainMenuScene;