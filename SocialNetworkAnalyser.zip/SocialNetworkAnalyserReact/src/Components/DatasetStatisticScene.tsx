import { Close } from '@mui/icons-material';
import { Autocomplete, CircularProgress, Dialog, DialogTitle, IconButton, TextField, Typography } from '@mui/material';
import moment from 'moment';

import { useEffect, useRef, useState } from 'react';
import { DatasetDTO, GetDatasetStatisticResponse } from '../Api/ApiServer';
import { ApiServerClient } from '../Api/ApiServerClient';
import ForceGraph2D, { ForceGraphMethods, GraphData } from 'react-force-graph-2d';

export interface DatasetStatisticSceneProps{
    open: boolean;
    onClose: (value: string) => void;
}

export default function DatasetStatisticScene(props: DatasetStatisticSceneProps) {
    const { onClose, open } = props;
    const graphRef = useRef<ForceGraphMethods>();

    const [selected, setSelected] = useState<DatasetDTO>();
    const [datasets, setDatasets] = useState<DatasetDTO[]>([]);
    const [statistic, setStatistic] = useState<GetDatasetStatisticResponse>();
    const [loading, setLoading] = useState(false);
    const [loadingGraph, setLoadingGraph] = useState(false);
    const [graphData, setGraphData] = useState<GraphData>();
    
    useEffect(() => {
        setLoading(false);
        setLoadingGraph(false);  
        clearGraphData();
        (new ApiServerClient()).GetDatasetsList().then((e) => {
            setDatasets(e); 
        });
    }, [open]);

    useEffect(() => {
       if (selected)
       {
            clearGraphData();
            setLoading(true);
            (new ApiServerClient()).GetDatasetStatistic(selected.id!).then((e) => {
                setStatistic(e);
                setLoading(false);
                setLoadingGraph(true); 
                (new ApiServerClient()).GetDatasetData(selected.id!).then((e) => {
                    let nodes = e.users!.map((v, i) => { return { id: v.id!.toString(), name: v.identifikator!.toString(), val: 1 }; });
                    let links = e.connections!.map((v, i) => { return { source: v.source!.toString(), target: v.target!.toString()}; });
                    if (nodes !== undefined && links !== undefined)
                    { 
                        setGraphData({
                        "nodes": nodes,
                        "links": links
                        });
                    }
                    else                    
                        setLoadingGraph(false); 
                });
            });
       }
       else
       {
            clearGraphData();
            setStatistic(undefined);
            setLoading(false);
            setLoadingGraph(false);
       }
       
    }, [selected]);

    function clearGraphData()
    {
        setGraphData({
            "nodes": [],
            "links": []
            });
    }

    function onStatisticClosed() {
        clearGraphData();
        setStatistic(undefined);
        setSelected(undefined);
        setLoading(false);
        setLoadingGraph(false);
        onClose("");
    }

    return (
        <Dialog maxWidth="lg" fullWidth open={open} onClose={onClose} style={{  marginTop: '10px' }}>
            <DialogTitle height='20px' sx={{ zIndex: "28" }}>
                <div style={{ zIndex: "200" }}>
                    <div style={{ float: 'left', display: 'flex' }}>
                        <Typography variant='h1' fontWeight='bold' fontSize={20} sx={{ marginTop: '-5px', marginRight: '5px' }}>Statistiky</Typography>
                    </div>
                    <div style={{ float: 'right', display: 'flex', alignContent: 'flex-end' }}>
                        <div style={{ marginTop: '-14px' }}>
                            <IconButton onClick={onStatisticClosed} >
                                <Close />
                            </IconButton>
                        </div>
                    </div>
                </div>
            </DialogTitle>
            <div style={{ margin: 'auto', minHeight: '450px', minWidth: '400px' }}>
                <div style={{ width: '100%' }}>
                    <Autocomplete
                        disablePortal
                        size="small"
                        onChange={(e, v) => {
                            setSelected(v === null? undefined : v);
                        }}
                        isOptionEqualToValue={(option, value) => option.id === value.id}
                        readOnly={false}
                        getOptionLabel={o => o !== null && o.date !== undefined ? moment(o!.date).format("DD.MM.yyyy h:mm:ss") : ""}
                        value={selected}
                        options={datasets}
                        sx={{ width: 280, margin: '10px' }}
                        renderInput={(params) => <TextField error={selected === undefined}  {...params}

                        />}
                    />
                </div>  
                {statistic && !loading && <div style={{ width: '100%' }}>
                    <div style={{ margin: '10px'}}>
                        Počet uživatelů: {statistic.userCount}
                    </div>
                    <div style={{ margin: '10px'}}>
                        Průměrný počet přátel: {statistic.avgUserFriends}
                    </div>
                </div> 
                }
                {loading && <div style={{ width: '100%' }}>
                    <div style={{ margin: '40px'}}>
                        <CircularProgress sx={{ opacity: '1', width: '16px', height: '16px', margin: 'auto', marginTop: '20px', marginLeft: '150px' }} />
                    </div>
                </div> 
                }
                <div style={{ height: 480, width: 640 }}>
                   {<div style={{ display: loadingGraph ? 'none' : 'block'}}>
                    <ForceGraph2D ref={graphRef} graphData={graphData} width={640} height={480} warmupTicks={100} enableZoomInteraction={false} cooldownTicks={0} 
                        onEngineStop={() => 
                        {
                            setLoadingGraph(false);
                            graphRef.current?.zoomToFit(2000); }} />
                    </div>
                    }
                    {loadingGraph && <CircularProgress sx={{ opacity: '1', width: '16px', height: '16px', margin: 'auto', marginTop: '140px', marginLeft: '150px' }} />
                     }
                </div>
                
            </div >            
        </Dialog >
    );    
};
