import React, { useEffect, useRef, useState } from 'react';
import { Button, Typography } from '@mui/material';
import { ApiServerClient } from '../Api/ApiServerClient';
import { FileParameter } from '../Api/ApiServer';

interface UploadFileComponentProps {
    onClose: () => void;
    onImporting: (stav: boolean) => void;
}

function UploadFileComponent(props: UploadFileComponentProps) {
    const { onClose, onImporting } = props;
    const upload = useRef<HTMLInputElement>(null);
    const [file, setFile] = useState<File | undefined>(undefined);
    const [message, setMessage] = useState<string | undefined>();
    const [isError, setIsError] = useState(false);

    useEffect(() => {
    }, []);

    function selectFile(e: React.ChangeEvent<HTMLInputElement>) {
        if (e.target.files !== null && e.target.files.length > 0)
            setFile(e.target.files![0]);
      }

    function onImportClicked() {     
        saveImport().then((saved) => {
            if (saved) {
                setFile(undefined);
                onClose();
            }  
            setIsError(true);          
            onImporting(false);      
        })
    }

    async function saveImport(): Promise<boolean> {
        try {
            if (file !== undefined) {
                onImporting(true);   
                let fileParameter: FileParameter = { fileName: file.name, data: file };
                let t = await (new ApiServerClient()).ImportDataset(fileParameter);
                onImporting(false);
                if (!t.ok) {
                    setIsError(true);
                    setMessage(t.errorMessage);
                    return false;
                }
                return true;
            }
            else
                return false;
        }
        catch
        {
            onImporting(false);
            return false;
        }
    }

    return (
        <div>
        <label htmlFor="btn-upload">
          <input
            id="btn-upload"
            name="btn-upload"
            style={{ display: 'none' }}
            type="file"
            ref={upload}
            onChange={selectFile} />
          <Button
            className="btn-choose"
            variant="outlined"
            component="span" >
             Vyberte soubor
          </Button>
        </label>
        <div className="file-name">
            {file ? file.name : null}
        </div>

        {isError && <Typography variant="h6" className="upload-message-error">
          {message}
        </Typography>
        }

        <Typography variant="h6" className="list-header">
          Vybraný soubor
        </Typography>
          {file && <Typography>
                {file.name} 
            </Typography>}
        <Button
          className="btn-upload"
          color="primary"
          variant="contained"
          component="span"
          disabled={!file}
          onClick={onImportClicked}>
          Importovat
        </Button>
      </div >
    );    
};
export default UploadFileComponent;