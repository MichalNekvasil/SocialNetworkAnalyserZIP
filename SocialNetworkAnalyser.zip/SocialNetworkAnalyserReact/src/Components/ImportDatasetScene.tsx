import { Close } from '@mui/icons-material';
import { CircularProgress, Dialog, DialogTitle, IconButton, Typography } from '@mui/material';

import { useEffect, useState } from 'react';
import UploadFileComponent from './UploadFileComponent';

export interface ImportDatasetSceneProps{
    open: boolean;
    onClose: (value: string) => void;
}

export default function ImportDatasetScene(props: ImportDatasetSceneProps) {
    const { onClose, open } = props;
    const [loading, setLoading] = useState<boolean>(false);
    
    useEffect(() => {
        setLoading(false);
    }, []);

    function newImportClosed() {
        onClose("");
    }

    function onImporting(e: boolean) {
        setLoading(e);
    }

    return (
        <Dialog maxWidth="lg" open={open} onClose={onClose} style={{  marginTop: '10px' }}>
            <DialogTitle height='20px' sx={{ backgroundColor: '#F5F5F5', zIndex: "28" }}>
                <div style={{ zIndex: "200" }}>
                    <div style={{ float: 'left', display: 'flex' }}>
                        <Typography variant='h1' fontWeight='bold' fontSize={20} sx={{ marginTop: '-5px', marginRight: '5px' }}>Import datasetu</Typography>
                    </div>
                    <div style={{ float: 'right', display: 'flex', alignContent: 'flex-end' }}>
                        <div style={{ marginTop: '-14px' }}>
                            <IconButton onClick={newImportClosed} >
                                <Close />
                            </IconButton>
                        </div>
                    </div>
                </div>
            </DialogTitle>
            {loading && <div style={{ margin: 'auto', minHeight: '250px', minWidth: '400px' }}>
                <CircularProgress sx={{ opacity: '1', width: '16px', height: '16px', margin: 'auto', marginTop: '30px', marginLeft: '168px' }} />
            </div>
            }
            {!loading && <div style={{ margin: 'auto', minHeight: '250px', minWidth: '400px' }}>
            <div style={{ width: '100%' }}>
                        <div style={{ margin: "10px" }}>
                            Nahrajte nový dataset
                        </div>
                        <div style={{ margin: '10px'}}>
                            <UploadFileComponent onClose={newImportClosed} onImporting={onImporting} />
                        </div>
                    </div>  
            </div >
            }
        </Dialog>
    );    
};
