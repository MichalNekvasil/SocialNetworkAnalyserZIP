import { DatasetDTO, FileParameter, GetDatasetDataResponse, GetDatasetsListRequest, GetDatasetStatisticResponse, ImportDatasetFileResponse } from "./ApiServer";
import { ApiServerBaseHelper } from "./ApiServerBaseHelper";

export class ApiServerClient extends ApiServerBaseHelper  {
    public async ImportDataset(file: FileParameter): Promise<ImportDatasetFileResponse> {
        return (await this.GetAdressedClient().importDatasetFile(file));
    }

    public async GetDatasetStatistic(id : number): Promise<GetDatasetStatisticResponse> {
        return (await this.GetAdressedClient().getDatasetStatistic(id));
    }

    public async GetDatasetData(id : number): Promise<GetDatasetDataResponse> {
        return (await this.GetAdressedClient().getDatasetData(id));
    }

    public async GetDatasetsList(): Promise<DatasetDTO[]> {
        return (await this.GetAdressedClient().getDatasetsList(new GetDatasetsListRequest())).seznam!;
    }
}