import axios, { AxiosInstance } from "axios";
import { NetworkAnalyserClient } from "./ApiServer";

export class ApiServerBaseHelper {

    protected GetAdressedClient(): NetworkAnalyserClient {
        return new NetworkAnalyserClient(this.GetApiAddress(), this.GetClient());
    }
    protected GetApiAddress(): string {
        // zde případně načtení jiné base URL např z ENV
        return '';
    }
    protected GetClient(): AxiosInstance {
        const axiosApiInstance = axios.create();
        return axiosApiInstance;
    }
}