using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Models;
using Moq;
using SocialNetworkAnalyserAPI.v1;
using Xunit;

namespace SocialNetworkAnalyserAPITest.Tests
{
    public class ImportDatasetFileHandlerTests
    {
        private readonly TestFixture _fixture;

        public ImportDatasetFileHandlerTests()
        {
            _fixture = new TestFixture(this.GetType().ToString());
        }

        [Fact]
        public async Task ImportDatasetFileHandler_ValidInput()
        {
            // Arrange
            var mockFormFile = new Mock<IFormFile>();
            var stream = new MemoryStream(Encoding.UTF8.GetBytes("1 2\n1 3\n"));
            mockFormFile.Setup(f => f.OpenReadStream())
                .Returns(stream);
            mockFormFile.Setup(f => f.FileName)
                .Returns("testfile.txt");

            var request = new ImportDatasetFileRequest { File = mockFormFile.Object };
            var handler = new ImportDatasetFileHandler(_fixture.Context);

            // Act
            var response = await handler.Handle(request, CancellationToken.None);

            // Assert
            Assert.True(response.Ok);
            Assert.Null(response.ErrorMessage);
            Assert.Single(_fixture.Context.DatasetImports);

            var datasetImport = _fixture.Context.DatasetImports.Single();
            Assert.Equal(3, datasetImport.Users.Count);

            var user1 = datasetImport.Users.SingleOrDefault(u => u.UserIdentifikator == 1);
            var user2 = datasetImport.Users.SingleOrDefault(u => u.UserIdentifikator == 2);
            var user3 = datasetImport.Users.SingleOrDefault(u => u.UserIdentifikator == 3);

            Assert.NotNull(user1);
            Assert.NotNull(user2);
            Assert.NotNull(user3);

            Assert.Contains(user2, user1.UsersB);
            Assert.Contains(user3, user1.UsersB);
        }

        [Fact]
        public async Task ImportDatasetFileHandler_InvalidInput()
        {
            // Arrange
            var mockFormFile = new Mock<IFormFile>();
            var stream = new MemoryStream(Encoding.UTF8.GetBytes("1\n2 3\n"));
            mockFormFile.Setup(f => f.OpenReadStream())
                .Returns(stream);
            mockFormFile.Setup(f => f.FileName)
                .Returns("testfile.txt");

            var request = new ImportDatasetFileRequest { File = mockFormFile.Object };
            var handler = new ImportDatasetFileHandler(_fixture.Context);

            // Act
            var response = await handler.Handle(request, CancellationToken.None);

            // Assert
            Assert.False(response.Ok);
            Assert.NotNull(response.ErrorMessage);
        }
    }
}
