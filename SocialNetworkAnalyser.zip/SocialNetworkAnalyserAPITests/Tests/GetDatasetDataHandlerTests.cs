using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Models;
using SocialNetworkAnalyserAPI.v1;
using Xunit;

namespace SocialNetworkAnalyserAPITest.Tests
{
    public class GetDatasetDataHandlerTests
    {
        private readonly TestFixture _fixture;

        public GetDatasetDataHandlerTests()
        {
            _fixture = new TestFixture(this.GetType().ToString());
        }

        [Fact]
        public async Task GetDatasetDataHandler_CorrectData()
        {

            // Arrange
            var ds = new DatasetImport { Created = DateTime.Now };
            _fixture.Context.Users.AddRange(new List<User>
            {
                new User { UserIdentifikator = 1, DatasetImport = ds },
                new User { UserIdentifikator = 2, DatasetImport = ds },
                new User { UserIdentifikator = 3, DatasetImport = ds },
                new User { UserIdentifikator = 4, DatasetImport = ds }
            });
            _fixture.Context.SaveChanges();

            // Add Users friends
            _fixture.Context.Users.Single(p => p.UserIdentifikator == 1).UsersB.Add(_fixture.Context.Users.Single(p => p.UserIdentifikator == 2));
            _fixture.Context.Users.Single(p => p.UserIdentifikator == 1).UsersB.Add(_fixture.Context.Users.Single(p => p.UserIdentifikator == 3));
            _fixture.Context.Users.Single(p => p.UserIdentifikator == 1).UsersB.Add(_fixture.Context.Users.Single(p => p.UserIdentifikator == 4));
            _fixture.Context.Users.Single(p => p.UserIdentifikator == 2).UsersB.Add(_fixture.Context.Users.Single(p => p.UserIdentifikator == 3));
            _fixture.Context.Users.Single(p => p.UserIdentifikator == 2).UsersB.Add(_fixture.Context.Users.Single(p => p.UserIdentifikator == 4));
            _fixture.Context.Users.Single(p => p.UserIdentifikator == 3).UsersB.Add(_fixture.Context.Users.Single(p => p.UserIdentifikator == 4));

            _fixture.Context.SaveChanges();
            var request = new GetDatasetDataRequest { Id = ds.Id };
            var handler = new GetDatasetDataHandler(_fixture.Context);

            // Act
            var response = await handler.Handle(request, CancellationToken.None);

            // Assert
            Assert.NotNull(response);
            Assert.Equal(4, response.Users.Count);
            Assert.Equal(6, response.Connections.Count);
        }
    }
}
