using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Models;
using Moq;
using SocialNetworkAnalyserAPI.v1;
using Xunit;

namespace SocialNetworkAnalyserAPITest.Tests
{
    public class GetDatasetsListHandlerTests
    {
        private readonly TestFixture _fixture;

        public GetDatasetsListHandlerTests()
        {
            _fixture = new TestFixture(this.GetType().ToString());
        }
        [Fact]
        public async Task GetDatasetsListHandler_ReturnsCorrectData()
        {
            // Arrange
            var datasetImports = new List<DatasetImport>
            {
                new DatasetImport { Created = DateTime.Now.AddDays(-2) },
                new DatasetImport { Created = DateTime.Now.AddDays(-1) },
                new DatasetImport { Created = DateTime.Now }
            };
            _fixture.Context.DatasetImports.AddRange(datasetImports);
            _fixture.Context.SaveChanges();
            var handler = new GetDatasetsListHandler(_fixture.Context);
            var request = new GetDatasetsListRequest();

            // Act
            var result = await handler.Handle(request, CancellationToken.None);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(datasetImports.Count, result.Seznam.Count);

            for (int i = 0; i < datasetImports.Count; i++)
            {
                var expected = new DatasetDTO { Id = datasetImports[i].Id, Date = datasetImports[i].Created };
                var actual = result.Seznam[i];
                Assert.Equal(expected.Date, actual.Date);
            }
        }
    }
}
