using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Models;
using Moq;
using SocialNetworkAnalyserAPI.v1;
using Xunit;

namespace SocialNetworkAnalyserAPITest.Tests
{
    public class GetDatasetStatisticHandlerTests
    {
        private readonly TestFixture _fixture;

        public GetDatasetStatisticHandlerTests()
        {
            _fixture = new TestFixture(this.GetType().ToString());
        }

        [Fact]
        public async Task GetDatasetStatisticHandler_ReturnsCorrectData()
        {
            // Arrange
            var datasetImport = new DatasetImport(){ Created = DateTime.Now };
            var user1 = new User() { UserIdentifikator = 1 };
            var user2 = new User() { UserIdentifikator = 2 };
            var user3 = new User() { UserIdentifikator = 3 };
            var user4 = new User() { UserIdentifikator = 4 };

            user1.UsersB.Add(user2);
            user1.UsersB.Add(user4);
            user2.UsersB.Add(user3);
            user3.UsersB.Add(user4);

            datasetImport.Users.Add(user1);
            datasetImport.Users.Add(user2);
            datasetImport.Users.Add(user3);
            datasetImport.Users.Add(user4);

            _fixture.Context.DatasetImports.Add(datasetImport);
            _fixture.Context.SaveChanges();

            var handler = new GetDatasetStatisticHandler(_fixture.Context);
            var request = new GetDatasetStatisticRequest { Id = datasetImport.Id };

            // Act
            var result = await handler.Handle(request, CancellationToken.None);

            // Assert
            Assert.Equal(4, result.UserCount);
            Assert.Equal(2, result.AvgUserFriends);
        }
    }
}
