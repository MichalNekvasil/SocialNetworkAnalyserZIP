using Microsoft.EntityFrameworkCore;
using Models;

public class TestFixture : IDisposable
{
    public SNAContext Context { get; private set; }

    public TestFixture(string testName)
    {
        var options = new DbContextOptionsBuilder<SNAContext>()
            .UseInMemoryDatabase(databaseName: "testDb_" + testName)
            .Options;

        Context = new SNAContext(options);
        Context.Database.EnsureCreated();
    }

    public void Dispose()
    {
        Context.Database.EnsureDeleted();
        Context.Dispose();
    }
}