namespace Models
{
    public class User
    {
        public User()
        {
            UsersA = new HashSet<User>();
            UsersB = new HashSet<User>();
        }
        public int Id { get;set;}
        public int UserIdentifikator { get;set; }
        public DatasetImport DatasetImport { get; set; }
        public ICollection<User> UsersA { get; set; }
        public ICollection<User> UsersB { get; set; }
    }
}