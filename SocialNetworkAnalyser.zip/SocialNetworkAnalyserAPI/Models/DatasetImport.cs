
namespace Models
{
    public class DatasetImport
    {
        public DatasetImport()
        {
            Users = new HashSet<User>();
        }

        public int Id {get;set;}
        public DateTime Created {get;set;}
        public ICollection<User> Users {get;set;}
    }
}