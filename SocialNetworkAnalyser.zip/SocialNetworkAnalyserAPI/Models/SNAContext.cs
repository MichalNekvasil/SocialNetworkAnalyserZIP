using Microsoft.EntityFrameworkCore;

namespace Models
{
    public class SNAContext: DbContext
    {
        public SNAContext() : base()
        {
        }

        public SNAContext(DbContextOptions<SNAContext> options)
            : base(options)
        {
        }


        public DbSet<DatasetImport> DatasetImports { get;set;}
        public DbSet<User> Users { get; set; }
    }
}