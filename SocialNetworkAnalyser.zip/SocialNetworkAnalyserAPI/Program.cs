using Microsoft.EntityFrameworkCore;
using MediatR;
using Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
string jsonFile = "appsettings.json";
if (!String.IsNullOrEmpty(builder.Environment.EnvironmentName))
    jsonFile = "appsettings." + builder.Environment.EnvironmentName + ".json";
IConfiguration configuration = new ConfigurationBuilder()
                            .AddJsonFile(jsonFile)
                            .Build();

builder.Services.AddControllers();
builder.Services.AddMediatR(AppDomain.CurrentDomain.GetAssemblies());

builder.Services.AddDbContext<SNAContext>(options =>
{
    options.UseMySql(configuration["ConnectionStrings:Data"], new MariaDbServerVersion("10.3"));
});

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

// migrate database - to ensure creating database on startup if not exists
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;

    var context = services.GetRequiredService<SNAContext>();    
    context.Database.Migrate();
}

app.Run();

    