using Microsoft.AspNetCore.Mvc;
using MediatR;
using SocialNetworkAnalyserAPI.Abstraction;
using SocialNetworkAnalyserAPI.v1;

namespace SocialNetworkAnalyserAPI.Controllers;

[ApiController]
[Route("[controller]")]
public class DatasetController : NSABaseController
{
    public DatasetController(IMediator mediator) : base(mediator)
    {
    }

    [HttpGet]
    [Route("GetDatasetStatistic/{Id}")]
    public async Task<ActionResult<GetDatasetStatisticResponse>> GetDatasetStatistic([FromRoute] GetDatasetStatisticRequest req) => await SendResponse(req);

    [HttpGet]
    [Route("GetDatasetData/{Id}")]
    public async Task<ActionResult<GetDatasetDataResponse>> GetDatasetData([FromRoute] GetDatasetDataRequest req) => await SendResponse(req);

    [HttpGet]
    [Route("GetDatasetsList")]
    public async Task<ActionResult<GetDatasetsListResponse>> GetDatasetsList([FromRoute] GetDatasetsListRequest req) => await SendResponse(req);

    [HttpPost]
    [Route("ImportDatasetFile")]
    public async Task<ImportDatasetFileResponse> ImportDatasetFile([FromForm] ImportDatasetFileRequest req) => await SendResponse(req);
    
}
