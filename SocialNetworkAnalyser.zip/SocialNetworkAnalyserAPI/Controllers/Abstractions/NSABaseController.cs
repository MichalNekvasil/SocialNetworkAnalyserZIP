using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace SocialNetworkAnalyserAPI.Abstraction;
public abstract class NSABaseController : ControllerBase
{
    private readonly IMediator _mediator;
    public NSABaseController(IMediator mediator)
    {
        _mediator = mediator;
    }
    protected async Task<T> SendResponse<T>(IRequest<T> parametr) where T : class
    {
        return await _mediator.Send<T>(parametr);
    }
}