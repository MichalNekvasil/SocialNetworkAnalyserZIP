using MediatR;
using Microsoft.EntityFrameworkCore;
using Models;

namespace SocialNetworkAnalyserAPI.v1;

public class GetDatasetsListRequest : IRequest<GetDatasetsListResponse>
{
}
public class GetDatasetsListResponse
{
    public List<DatasetDTO> Seznam {get;set;}
}

public class DatasetDTO
{
    public int Id { get; set; }
    public DateTime Date { get; set; }
}
public class GetDatasetsListHandler : IRequestHandler<GetDatasetsListRequest, GetDatasetsListResponse>
{
    private readonly SNAContext _ctx;
    public GetDatasetsListHandler(SNAContext ctx)
    {
        _ctx = ctx;
    }
   
    public async Task<GetDatasetsListResponse> Handle(GetDatasetsListRequest request, CancellationToken cancellationToken)
    {
        return new GetDatasetsListResponse() { Seznam = _ctx.DatasetImports.Select(p => new DatasetDTO() { Date = p.Created, Id = p.Id }).ToList() };
    }
}