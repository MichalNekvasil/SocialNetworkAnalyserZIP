using System.Text;
using MediatR;
using Models;

namespace SocialNetworkAnalyserAPI.v1;

public class ImportDatasetFileRequest : IRequest<ImportDatasetFileResponse>
{
    public IFormFile File { get; set; } = null!;
}
public class ImportDatasetFileResponse
{
    public bool Ok { get; set; }
    public string? ErrorMessage { get; set; }
}
public class ImportDatasetFileHandler : IRequestHandler<ImportDatasetFileRequest, ImportDatasetFileResponse>
{
    private readonly SNAContext _ctx;
    public ImportDatasetFileHandler(SNAContext ctx)
    {
        _ctx = ctx;
    }
    public async Task<ImportDatasetFileResponse> Handle(ImportDatasetFileRequest request, CancellationToken cancellationToken)
    {
        if (request.File != null)
        {
            try
            {
                var str = request.File.OpenReadStream();                
                TextReader reader = new StreamReader(str, true);
                
                var newDataset = new DatasetImport(){ Created = DateTime.Now };

                string line;                
                while ((line = reader.ReadLine()) != null) 
                {
                    if (String.IsNullOrWhiteSpace(line))
                        continue;

                    string[] items = line.Trim().Split(" ");
                    if (items.Count() != 2)
                        return new ImportDatasetFileResponse() { Ok = false, ErrorMessage = "Bad data input" }; // zde případně continue; pokud chci ignorovat chyby

                    int first;
                    int second;
                    if (Int32.TryParse(items[0], out first) && Int32.TryParse(items[1], out second))
                    {
                        if (!newDataset.Users.Any(p => p.UserIdentifikator == first))
                            newDataset.Users.Add(new User() { UserIdentifikator = first } );
                        if (!newDataset.Users.Any(p => p.UserIdentifikator == second))
                            newDataset.Users.Add(new User() { UserIdentifikator = second } );

                        newDataset.Users.Single(p => p.UserIdentifikator == first).UsersB.Add(newDataset.Users.Single(p => p.UserIdentifikator == second));
                    }
                    else // vynechat pokud chci ignorovat chyby
                        return new ImportDatasetFileResponse() { Ok = false, ErrorMessage = "Bad data input" };                    
                }
                _ctx.DatasetImports.Add(newDataset);
                _ctx.SaveChanges();
            }
            catch (Exception ex)
            {
                return new ImportDatasetFileResponse() { Ok = false, ErrorMessage = ex.Message };
            }
        }
        return new ImportDatasetFileResponse() { Ok = true };
    }
}