using MediatR;
using Microsoft.EntityFrameworkCore;
using Models;

namespace SocialNetworkAnalyserAPI.v1;

public class GetDatasetStatisticRequest : IRequest<GetDatasetStatisticResponse>
{
    public int Id { get; set; }
}
public class GetDatasetStatisticResponse
{
    public int UserCount {get; set;}
    public double AvgUserFriends { get;set;}
}
public class GetDatasetStatisticHandler : IRequestHandler<GetDatasetStatisticRequest, GetDatasetStatisticResponse>
{
    private readonly SNAContext _ctx;
    public GetDatasetStatisticHandler(SNAContext ctx)
    {
        _ctx = ctx;
    }
   
    public async Task<GetDatasetStatisticResponse> Handle(GetDatasetStatisticRequest request, CancellationToken cancellationToken)
    {
        var data = _ctx.DatasetImports.Include(p =>p.Users).ThenInclude(p => p.UsersB).Single(p => p.Id == request.Id);
        return new GetDatasetStatisticResponse(){ UserCount = data.Users.Count, AvgUserFriends = ((double)data.Users.SelectMany(p =>p.UsersB).Count() / (double)data.Users.Count()) * 2 /* krát dva protože vazba obousměrná, případně součet UsersA.Count a UsersB.Count */ };
    }
}