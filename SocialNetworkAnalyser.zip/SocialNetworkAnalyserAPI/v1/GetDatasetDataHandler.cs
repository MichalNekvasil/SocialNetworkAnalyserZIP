using MediatR;
using Microsoft.EntityFrameworkCore;
using Models;

namespace SocialNetworkAnalyserAPI.v1;

public class GetDatasetDataRequest : IRequest<GetDatasetDataResponse>
{
    public int Id { get; set; }
}
public class GetDatasetDataResponse
{
    public List<UserDataDTO> Users { get; set; }
    public List<ConnectionDTO> Connections {get;set;}
}
public class UserDataDTO
{
    public int Id { get;set; }
    public int Value { get;set; }
    public int Identifikator { get;set; }
}
public class ConnectionDTO
{
    public int Source { get;set;}
    public int Target { get; set; }
}

public class GetDatasetDataHandler : IRequestHandler<GetDatasetDataRequest, GetDatasetDataResponse>
{
    private readonly SNAContext _ctx;
    public GetDatasetDataHandler(SNAContext ctx)
    {
        _ctx = ctx;
    }
   
    public async Task<GetDatasetDataResponse> Handle(GetDatasetDataRequest request, CancellationToken cancellationToken)
    {
        var data = _ctx.Users.Include(p => p.DatasetImport).Include(p => p.UsersB).Where(p => p.DatasetImport.Id == request.Id).ToList();
        List<ConnectionDTO> connections = new List<ConnectionDTO>();

        foreach (var u in data)
        {
            connections.AddRange(u.UsersB.Select(p => new ConnectionDTO(){ Source = u.Id, Target = p.Id}));
        }

        return new GetDatasetDataResponse(){ Users = data.Select(p => new UserDataDTO() { Id = p.Id, Identifikator = p.UserIdentifikator, Value = 1 /* zde případně počet přátel, jako váha usera */}).ToList(), Connections = connections };
    }
} 